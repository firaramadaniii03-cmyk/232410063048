<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Kasir</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <style>
    /* Import Google Font */
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap');

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Poppins', sans-serif;
    }

    body {
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        background: linear-gradient(135deg, #00c6ff, #0072ff);
        animation: backgroundShift 20s ease infinite alternate;
    }

    @keyframes backgroundShift {
        0% { background-position: 0% 50%; }
        100% { background-position: 100% 50%; }
    }

    .login-box {
        background: rgba(255, 255, 255, 0.15);
        padding: 40px 30px;
        border-radius: 20px;
        box-shadow:
            0 8px 32px 0 rgba(31, 38, 135, 0.37),
            0 0 0 1px rgba(255, 255, 255, 0.18);
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        width: 350px;
        text-align: center;
        animation: fadeIn 1s ease forwards;
        border: 1px solid rgba(255, 255, 255, 0.25);
        color: #fff;
    }

    .login-box h2 {
        margin-bottom: 25px;
        font-weight: 700;
        letter-spacing: 1.2px;
        text-shadow: 0 2px 5px rgba(0,0,0,0.3);
        color: #fff;
    }

    .input-group {
        margin-bottom: 20px;
        text-align: left;
    }

    .input-group label {
        font-size: 14px;
        color: #e0e0e0;
        margin-bottom: 8px;
        display: block;
        font-weight: 500;
    }

    .input-group input {
        width: 100%;
        padding: 12px;
        border-radius: 12px;
        border: none;
        background: rgba(255, 255, 255, 0.25);
        font-size: 14px;
        color: #fff;
        transition: background-color 0.3s ease, box-shadow 0.3s ease;
        box-shadow: inset 1px 1px 3px rgba(255,255,255,0.3);
    }

    .input-group input::placeholder {
        color: #ddd;
        font-style: italic;
    }

    .input-group input:focus {
        background: rgba(255, 255, 255, 0.4);
        outline: none;
        box-shadow:
            0 0 8px 2px rgba(0, 114, 255, 0.7),
            inset 1px 1px 4px rgba(255,255,255,0.6);
    }

    .btn {
        width: 100%;
        padding: 14px;
        border: none;
        border-radius: 30px;
        background: linear-gradient(135deg, #667eea, #764ba2);
        color: white;
        font-size: 17px;
        font-weight: 700;
        cursor: pointer;
        box-shadow: 0 6px 15px rgba(102, 126, 234, 0.5);
        transition: background 0.4s ease, box-shadow 0.4s ease, transform 0.2s ease;
    }

    .btn:hover {
        background: linear-gradient(135deg, #5a67d8, #6b46c1);
        box-shadow: 0 10px 25px rgba(107, 70, 193, 0.7);
        transform: translateY(-3px);
    }

    .extra {
        margin-top: 20px;
        font-size: 14px;
        color: #ddd;
    }

    .extra a {
        text-decoration: none;
        color: #87CEEB;
        font-weight: 600;
        transition: color 0.3s ease;
    }

    .extra a:hover {
        color: #d0e8ff;
        text-decoration: underline;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(-20px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
</style>

</head>

<body>
    <div class="login-box">
        <h2>Login</h2>
        <form action="proses/proses_login.php" method="POST">
            <div class="input-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="input-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" class="btn">Masuk</button>
            <div class="extra">
                <p>Belum punya akun? <a href="register.php">Daftar</a></p>
            </div>
        </form>
    </div>
</body>

</html>