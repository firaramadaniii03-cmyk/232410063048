<?php
session_start();

function cekLogin()
{
    if (!isset($_SESSION['UserID'])) {
        header("Location: ../index.php");
        exit();
    }
}

function hakAkses($level)
{
    if ($_SESSION['Level'] != $level) {
        //Aarahkan ke halaman error pengguna jika tidak memiliki akses 
        header("Location: dashboard.php");
        exit();
    }
}
