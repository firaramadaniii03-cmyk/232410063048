<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Beauty Store</title>

    <!-- Bootstrap 5 CSS -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">

    <!-- Bootstrap Icons (optional, for better UI) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        .navbar-brand img {
            height: 40px;
            margin-right: 10px;
        }

        .navbar-brand-text {
            font-weight: bold;
            font-size: 1.25rem;
        }

        .navbar .nav-link {
            font-weight: 500;
        }

        .navbar .btn-logout {
            margin-left: 10px;
        }

        .navbar-user {
            font-weight: 600;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
        <div class="container">
            <!-- Brand dan Logo -->
            <a class="navbar-brand d-flex align-items-center" href="../halaman/dashboard.php">
                <img src="../assets/beauty.jpg" alt="Logo">
                <span class="navbar-brand-text">Beauty Store</span>
            </a>

            <!-- Toggle Button -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Navigation Items -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="../halaman/dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../halaman/penjualan.php">Penjualan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../halaman/produk.php">Produk</a>
                    </li>
                    <?php if ($_SESSION['Level'] == 'administrator'): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="../halaman/user.php">Manajemen User</a>
                        </li>
                    <?php endif; ?>
                </ul>

                <!-- User Info and Logout -->
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item d-flex align-items-center">
                        <span class="nav-link text-white navbar-user">Halo, <?= htmlspecialchars($_SESSION['Username']); ?>!</span>
                    </li>
                    <li class="nav-item">
                        <a class="btn btn-danger btn-sm text-white btn-logout" href="../proses/proses_logout.php">
                            <i class="bi bi-box-arrow-right"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Konten Halaman -->
    <div class="container mt-4">