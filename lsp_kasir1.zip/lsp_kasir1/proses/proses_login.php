<?php
session_start();
include '../config/koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT * FROM user Where Username='$username' AND Password='$password'";
    $result = mysqli_query($koneksi, $query);

    if (mysqli_num_rows($result) > 0) {
        $data = mysqli_fetch_assoc($result);
        $_SESSION['UserID'] = $data['UserID'];
        $_SESSION['Username'] = $data['Username'];
        $_SESSION['Level'] = $data['Level'];

        //arahkan ke dashboard sesuai level
        header("Location: ../halaman/dashboard.php");
        exit();
    } else {
        echo "Username atau Passsword salah!";
    }
}
