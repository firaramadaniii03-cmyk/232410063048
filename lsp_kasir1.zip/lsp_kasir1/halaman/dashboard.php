<?php
include '../fungsi/autentikasi.php';
cekLogin();
include '../templates/header.php'; // Sertakan header
?>
<h2>Selamat datang, <?= $_SESSION['Username']; ?>!</h2>
<p>Anda login sebagai: <strong><?= $_SESSION['Level']; ?></strong></p>
    <hr>
    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="card text-white bg-info shadow">
                <div class="card-body">
                    <h5 class="card-title"><i class="bi bi-box-seam"></i> Jumlah Produk</h5>
                    <p class="card-text display-4">15</p>
                    <a href="produk.php" class="btn btn-outline-light">Lihat Detail</a>
                </div>
            </div>
        </div>
        <div class="col-md-6 mb-4">
            <div class="card text-white bg-success shadow">
                <div class="card-body">
                    <h5 class="card-title"><i class="bi bi-currency-dollar"></i> Total Transaksi Hari Ini</h5>
                    <p class="card-text display-4">Rp 500.000</p>
                    <a href="penjualan.php" class="btn btn-outline-light">Lihat Detail</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include '../templates/footer.php';//sertakan footer
?>
<style>
    /* Background: tambah gradasi lebih lembut dan subtle animasi */
    body {
        background: linear-gradient(135deg, #001F4D, #0059B3);
        min-height: 100vh;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        animation: gradientShift 15s ease infinite;
    }

    @keyframes gradientShift {
        0%, 100% {
            background: linear-gradient(135deg, #001F4D, #0059B3);
        }
        50% {
            background: linear-gradient(135deg, #004080, #3399FF);
        }
    }

    /* Glassmorphism cards - sedikit lebih transparan dan shadow lebih halus */
    .card.bg-info,
    .card.bg-success {
        background: rgba(255, 255, 255, 0.12) !important;
        border: 1.5px solid rgba(255, 255, 255, 0.2);
        backdrop-filter: blur(20px);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
        color: #f0f0f0 !important;
        border-radius: 15px;
        transition: transform 0.4s ease, box-shadow 0.4s ease;
    }

    /* Hover card: lebih smooth dan naik sedikit lebih tinggi */
    .card.bg-info:hover,
    .card.bg-success:hover {
        transform: translateY(-12px);
        box-shadow: 0 18px 50px rgba(0, 0, 0, 0.25);
    }

    /* Icon card: tambah shadow lembut untuk efek "glow" */
    .card-title i {
        color: #FFFDD0;
        margin-right: 10px;
        font-size: 1.8rem;
        text-shadow: 0 0 8px rgba(255, 253, 208, 0.6);
    }

    /* Judul card: font lebih besar & bold */
    .card-title {
        font-weight: 700;
        font-size: 1.5rem;
        letter-spacing: 0.03em;
    }

    /* Jumlah & total transaksi: tambahkan efek shadow pada teks */
    .card-text.display-4 {
        font-weight: 800;
        font-size: 3.5rem;
        letter-spacing: 2px;
        margin-bottom: 20px;
        text-shadow: 0 2px 8px rgba(0,0,0,0.4);
    }

    /* Tombol: buat rounded penuh dan tambahkan efek transisi warna */
    .btn-outline-light {
        border-color: #fff;
        color: #fff;
        font-weight: 700;
        border-radius: 30px;
        padding: 10px 22px;
        font-size: 1rem;
        transition: background-color 0.35s ease, color 0.35s ease, box-shadow 0.35s ease;
        box-shadow: 0 2px 10px rgba(255,255,255,0.3);
    }

    .btn-outline-light:hover {
        background-color: rgba(255, 255, 255, 0.3);
        color: #001F4D;
        border-color: rgba(255, 255, 255, 0.85);
        box-shadow: 0 8px 30px rgba(255, 255, 255, 0.5);
    }

    /* Heading dan teks login: tambah shadow sedikit lebih tegas */
    h2, p, strong {
        color: #f0f0f0;
        text-shadow: 0 2px 6px rgba(0,0,0,0.65);
    }
</style>
