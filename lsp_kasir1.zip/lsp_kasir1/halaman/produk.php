<?php
include '../fungsi/autentikasi.php';
cekLogin();
include '../config/koneksi.php';

// Ambil kata kunci pencarian dari URL jika ada
$search_query = isset($_GET['search']) ? $_GET['search'] : '';

// Ambil data produk dengan filter pencarian
$query = "SELECT ProdukID, NamaProduk, Harga, Stok FROM produk";
if (!empty($search_query)) {
    // Tambahkan kondisi WHERE untuk pencarian
    $query .= " WHERE NamaProduk LIKE '%" . mysqli_real_escape_string($koneksi, $search_query) . "%'";
}

$result = mysqli_query($koneksi, $query);

include '../templates/header.php';

// Menampilkan pesan sukses atau error jika ada
if (isset($_GET['pesan']) && $_GET['pesan'] == 'sukses') {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">Data produk berhasil disimpan!
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
}
if (isset($_GET['pesan']) && $_GET['pesan'] == 'edit_sukses') {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">Data produk berhasil diperbarui!
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
}
if (isset($_GET['pesan']) && $_GET['pesan'] == 'hapus_sukses') {
    echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">Data produk berhasil dihapus!
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
}
?>

<h2>Manajemen Produk</h2>
<div class="row mb-3">
    <div class="col-md-6">
        <!-- Tombol "Tambah Produk" hanya untuk role 'administrator' -->
        <?php if ($_SESSION['Level'] == 'administrator'): ?>
            <a href="tambah_produk.php" class="btn btn-primary ms-2">Tambah Produk</a>
        <?php endif; ?>
    </div>
    <div class="col-md-6">
        <form action="" method="GET" class="d-flex">
            <input class="form-control me-2" type="search" placeholder="Cari produk..." aria-label="Search" name="search" value="<?= htmlspecialchars($search_query); ?>">
            <button class="btn btn-outline-success" type="submit">Cari</button>
        </form>
    </div>
</div>

<div class="table-responsive">
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Produk</th>
                <th>Harga</th>
                <th>Stok</th>
                <!-- Kolom "Aksi" hanya untuk role 'administrator' -->
                <?php if ($_SESSION['Level'] == 'administrator'): ?>
                    <th>Aksi</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            while ($row = mysqli_fetch_assoc($result)):
            ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $row['NamaProduk']; ?></td>
                    <td>Rp <?= number_format($row['Harga'], 0, ',', '.'); ?></td>
                    <td><?= $row['Stok']; ?></td>
                    <!-- Tombol "Aksi" hanya untuk role 'administrator' -->
                    <?php if ($_SESSION['Level'] == 'administrator'): ?>
                        <td>
                            <a href="edit_produk.php?id=<?= $row['ProdukID']; ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="../proses/proses_hapus_produk.php?id=<?= $row['ProdukID']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus produk ini?');">Hapus</a>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include '../templates/footer.php'; ?>
<style>
    body {
        background: #f0f8ff;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        padding: 30px;
        color: #222;
    }

    h2 {
        color: #004080;
        font-weight: 700;
        margin-bottom: 25px;
        text-align: center;
    }

    /* Tombol Tambah Produk */
    .btn-primary {
        background: linear-gradient(135deg, #0059b3, #003366);
        border: none;
        font-weight: 700;
        border-radius: 10px;
        padding: 10px 20px;
        transition: background 0.3s ease;
    }
    .btn-primary:hover {
        background: linear-gradient(135deg, #003366, #001f4d);
    }

    /* Form pencarian */
    form.d-flex {
        gap: 10px;
    }

    .form-control {
        border-radius: 8px;
        border: 1.5px solid #a0cfff;
        padding: 8px 12px;
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
        font-size: 1rem;
    }
    .form-control:focus {
        border-color: #0059b3;
        box-shadow: 0 0 6px rgba(0, 89, 179, 0.6);
        outline: none;
    }

    .btn-outline-success {
        border-radius: 8px;
        font-weight: 600;
        border-color: #007a33;
        color: #007a33;
        transition: all 0.3s ease;
    }
    .btn-outline-success:hover {
        background-color: #007a33;
        color: white;
        border-color: #005d26;
    }

    /* Table styling */
    .table-responsive {
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        background: white;
    }

    table {
        border-collapse: separate;
        border-spacing: 0 12px;
        width: 100%;
        font-size: 1rem;
        color: #004080;
    }

    thead th {
        background: #0059b3;
        color: white;
        padding: 12px 15px;
        border-radius: 10px 10px 0 0;
        font-weight: 700;
        text-align: center;
    }

    tbody tr {
        background: #e6f0ff;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0, 89, 179, 0.1);
        transition: background 0.3s ease;
    }

    tbody tr:hover {
        background: #cce0ff;
    }

    tbody td {
        padding: 12px 15px;
        text-align: center;
        vertical-align: middle;
    }

    /* Tombol edit & hapus */
    .btn-warning {
        background: linear-gradient(135deg, #ffcc00, #cc9900);
        border: none;
        border-radius: 8px;
        font-weight: 600;
        padding: 5px 10px;
        transition: background 0.3s ease;
        color: #4a3c00;
    }
    .btn-warning:hover {
        background: #cc9900;
        color: #3a2e00;
    }

    .btn-danger {
        background: linear-gradient(135deg, #cc3300, #990000);
        border: none;
        border-radius: 8px;
        font-weight: 600;
        padding: 5px 10px;
        transition: background 0.3s ease;
        color: white;
    }
    .btn-danger:hover {
        background: #990000;
    }

    /* Alert pesan sukses & warning */
    .alert {
        max-width: 900px;
        margin: 20px auto;
        border-radius: 12px;
        font-weight: 600;
        box-shadow: 0 6px 15px rgba(0,0,0,0.1);
    }

    /* Responsive */
    @media (max-width: 768px) {
        .table-responsive {
            box-shadow: none;
        }
        table thead {
            display: none;
        }
        table, tbody, tr, td {
            display: block;
            width: 100%;
        }
        tbody tr {
            margin-bottom: 20px;
            box-shadow: 0 4px 10px rgba(0, 89, 179, 0.1);
            background: #e6f0ff;
            border-radius: 12px;
            padding: 15px;
        }
        tbody td {
            text-align: right;
            padding-left: 50%;
            position: relative;
            border: none;
            font-size: 0.9rem;
        }
        tbody td::before {
            content: attr(data-label);
            position: absolute;
            left: 15px;
            width: 45%;
            font-weight: 700;
            text-align: left;
            color: #004080;
        }
    }
</style>
