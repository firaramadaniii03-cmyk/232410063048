<?php
include '../fungsi/autentikasi.php';
cekLogin();
include '../config/koneksi.php';

// Ambil data produk untuk dropdown
$query_produk = "SELECT ProdukID, NamaProduk, Harga, Stok FROM produk WHERE Stok > 0";
$result_produk = mysqli_query($koneksi, $query_produk);

// Ambil data pelanggan untuk dropdown
$query_pelanggan = "SELECT PelangganID, NamaPelanggan FROM pelanggan WHERE PelangganID != 1";
$result_pelanggan = mysqli_query($koneksi, $query_pelanggan);

include '../templates/header.php';
?>

<h2>Transaksi Penjualan</h2>

<form action="../proses/proses_penjualan.php" method="POST">
    <div class="form-group">
        <label for="pelanggan_id">Pelanggan</label>
        <select name="pelanggan_id" class="form-control">
            <option value="1" selected>-- Pilih Pelanggan --</option>
            <?php while ($row_pelanggan = mysqli_fetch_assoc($result_pelanggan)): ?>
                <option value="<?= $row_pelanggan['PelangganID']; ?>"><?= $row_pelanggan['NamaPelanggan']; ?></option>
            <?php endwhile; ?>
        </select>
    </div>

    <hr>
    <h4>Pilih Barang</h4>
    <div class="form-row mb-3">
        <div class="col-md-5">
            <label for="produk_input">Produk</label>
            <select id="produk_input" class="form-control">
                <option value="">-- Pilih Produk --</option>
                <?php mysqli_data_seek($result_produk, 0); ?>
                <?php while ($row_produk = mysqli_fetch_assoc($result_produk)): ?>
                    <option value="<?= $row_produk['ProdukID']; ?>"
                        data-harga="<?= $row_produk['Harga']; ?>"
                        data-nama="<?= $row_produk['NamaProduk']; ?>"
                        data-stok="<?= $row_produk['Stok']; ?>">
                        <?= $row_produk['NamaProduk']; ?> (Stok: <?= $row_produk['Stok']; ?>)
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="col-md-3">
            <label for="jumlah_input">Jumlah</label>
            <input type="number" id="jumlah_input" class="form-control" min="1" value="1">
        </div>
        <div class="col-md-4 d-flex align-items-end">
            <button type="button" class="btn btn-primary btn-block" id="tambah-keranjang">Tambah ke Keranjang</button>
        </div>
    </div>

    <hr>
    <h4>Keranjang Belanja</h4>
    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Produk</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Subtotal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody id="keranjang-body">
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3" class="text-right"><strong>Total Harga</strong></td>
                    <td colspan="2"><strong id="total-harga-display">Rp 0</strong></td>
                </tr>
            </tfoot>
        </table>
    </div>

    <div id="keranjang-inputs"></div>

    <input type="hidden" name="total_harga" id="total_harga">
    <button type="submit" class="btn btn-success btn-block mt-3" id="simpan-transaksi" disabled>Simpan Transaksi</button>
</form>

<?php
include '../templates/footer.php';
?>
<script>
    $(document).ready(function() {
        let keranjang = {};

        function hitungTotal() {
            let total = 0;
            for (const id in keranjang) {
                total += keranjang[id].subtotal;
            }
            $('#total-harga-display').text('Rp ' + total.toLocaleString('id-ID'));
            $('#total_harga').val(total);

            if (Object.keys(keranjang).length > 0) {
                $('#simpan-transaksi').removeAttr('disabled');
            } else {
                $('#simpan-transaksi').attr('disabled', 'disabled');
            }
        }

        function renderKeranjang() {
            $('#keranjang-body').empty();
            $('#keranjang-inputs').empty();

            for (const id in keranjang) {
                const item = keranjang[id];
                const row = `
                <tr>
                    <td>${item.nama}</td>
                    <td>Rp ${item.harga.toLocaleString('id-ID')}</td>
                    <td>
                        <input type="number" class="form-control jumlah-keranjang" data-id="${item.id}" value="${item.jumlah}" min="1" max="${item.stok}">
                    </td>
                    <td>Rp ${item.subtotal.toLocaleString('id-ID')}</td>
                    <td>
                        <button type="button" class="btn btn-danger btn-sm hapus-keranjang" data-id="${item.id}">Hapus</button>
                    </td>
                </tr>
            `;
                $('#keranjang-body').append(row);

                // Tambahkan input hidden untuk dikirim ke PHP
                const inputHidden = `
                <input type="hidden" name="produk_id[]" value="${item.id}">
                <input type="hidden" name="jumlah[]" value="${item.jumlah}">
            `;
                $('#keranjang-inputs').append(inputHidden);
            }
            hitungTotal();
        }

        // Aksi tombol "Tambah ke Keranjang"
        $('#tambah-keranjang').click(function() {
            const produkInput = $('#produk_input');
            const jumlahInput = $('#jumlah_input');

            const produkID = produkInput.val();
            const jumlah = parseInt(jumlahInput.val());
            const harga = parseFloat(produkInput.find('option:selected').data('harga'));
            const nama = produkInput.find('option:selected').data('nama');
            const stok = parseInt(produkInput.find('option:selected').data('stok'));

            if (produkID && jumlah > 0 && jumlah <= stok) {
                if (keranjang[produkID]) {
                    const newJumlah = keranjang[produkID].jumlah + jumlah;
                    if (newJumlah > stok) {
                        alert('Jumlah melebihi stok yang tersedia!');
                        return;
                    }
                    keranjang[produkID].jumlah = newJumlah;
                    keranjang[produkID].subtotal = newJumlah * harga;
                } else {
                    keranjang[produkID] = {
                        id: produkID,
                        nama: nama,
                        harga: harga,
                        jumlah: jumlah,
                        stok: stok,
                        subtotal: harga * jumlah
                    };
                }
                renderKeranjang();
            } else if (jumlah > stok) {
                alert('Jumlah melebihi stok yang tersedia!');
            } else {
                alert('Silakan pilih produk dan jumlah yang valid.');
            }
        });

        // Aksi tombol "Hapus" dari keranjang
        $(document).on('click', '.hapus-keranjang', function() {
            const produkID = $(this).data('id');
            delete keranjang[produkID];
            renderKeranjang();
        });

        // Update jumlah di keranjang
        $(document).on('change', '.jumlah-keranjang', function() {
            const produkID = $(this).data('id');
            const newJumlah = parseInt($(this).val());
            const stok = keranjang[produkID].stok;

            if (newJumlah <= 0 || newJumlah > stok) {
                alert('Jumlah tidak valid atau melebihi stok!');
                $(this).val(keranjang[produkID].jumlah);
                return;
            }

            keranjang[produkID].jumlah = newJumlah;
            keranjang[produkID].subtotal = newJumlah * keranjang[produkID].harga;
            renderKeranjang();
        });
    });
</script>
<style>
    /* Body dan container */
    body {
        background: linear-gradient(135deg, #e0f2ff, #a0cfff);
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        padding: 30px;
        color: #333;
    }

    h2, h4 {
        color: #004080;
        margin-bottom: 20px;
        font-weight: 700;
    }

    form {
        background: #ffffffcc; /* putih transparan */
        padding: 25px 30px;
        border-radius: 15px;
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        max-width: 900px;
        margin: 0 auto 50px auto;
    }

    /* Label dan input */
    label {
        font-weight: 600;
        color: #004080;
    }

    .form-control {
        border-radius: 8px;
        border: 1.8px solid #a0cfff;
        padding: 10px 12px;
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
        font-size: 1rem;
    }

    .form-control:focus {
        border-color: #0059b3;
        box-shadow: 0 0 8px rgba(0, 89, 179, 0.5);
        outline: none;
    }

    /* Tombol */
    .btn-primary {
        background: linear-gradient(135deg, #0059b3, #004080);
        border: none;
        font-weight: 700;
        border-radius: 10px;
        padding: 12px 25px;
        transition: background 0.3s ease;
    }

    .btn-primary:hover {
        background: linear-gradient(135deg, #003366, #002244);
    }

    .btn-success {
        background: linear-gradient(135deg, #007a33, #004d1a);
        border: none;
        font-weight: 700;
        border-radius: 10px;
        padding: 12px 25px;
        transition: background 0.3s ease;
    }

    .btn-success:hover {
        background: linear-gradient(135deg, #004d1a, #002d0a);
    }

    /* Table styling */
    table {
        border-collapse: separate;
        border-spacing: 0 12px;
        width: 100%;
        font-size: 1rem;
        color: #004080;
    }

    thead th {
        background: #0059b3;
        color: white;
        padding: 12px 15px;
        border-radius: 10px 10px 0 0;
        text-align: center;
        font-weight: 700;
    }

    tbody tr {
        background: #e6f0ff;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0, 89, 179, 0.1);
        transition: background 0.3s ease;
    }

    tbody tr:hover {
        background: #cce0ff;
    }

    tbody td {
        padding: 12px 15px;
        text-align: center;
        vertical-align: middle;
    }

    /* Input jumlah di keranjang */
    .jumlah-keranjang {
        width: 70px;
        margin: 0 auto;
        border-radius: 6px;
        border: 1.5px solid #a0cfff;
        transition: border-color 0.3s ease;
    }

    .jumlah-keranjang:focus {
        border-color: #0059b3;
        box-shadow: 0 0 6px rgba(0, 89, 179, 0.6);
        outline: none;
    }

    /* Responsive */
    @media (max-width: 768px) {
        form {
            padding: 15px 20px;
        }

        .form-row > div {
            margin-bottom: 15px;
        }

        table thead {
            display: none;
        }

        table, tbody, tr, td {
            display: block;
            width: 100%;
        }

        tbody tr {
            margin-bottom: 20px;
            box-shadow: none;
            background: #e6f0ff;
            border-radius: 10px;
            padding: 15px;
        }

        tbody td {
            text-align: right;
            padding-left: 50%;
            position: relative;
        }

        tbody td::before {
            content: attr(data-label);
            position: absolute;
            left: 15px;
            width: 45%;
            padding-left: 10px;
            font-weight: 700;
            text-align: left;
            color: #004080;
        }

        .jumlah-keranjang {
            width: 100%;
        }
    }
</style>
