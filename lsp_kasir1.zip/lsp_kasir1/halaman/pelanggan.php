<?php
include '../fungsi/autentikasi.php';
cekLogin();
include '../config/koneksi.php';

// Cek level pengguna
$level_user = $_SESSION['Level'];

// Ambil data pelanggan dari database
$query = "SELECT * FROM pelanggan";
$result = mysqli_query($koneksi, $query);

include '../templates/header.php';
?>

<h2>Manajemen Pelanggan</h2>
<div class="row mb-3">
    <div class="col">
        <a href="dashboard.php" class="btn btn-secondary">Kembali</a>
    </div>
    <?php if ($level_user == 'petugas'): ?>
        <div class="col text-end">
            <a href="tambah_pelanggan.php" class="btn btn-primary">Tambah Pelanggan</a>
        </div>
    <?php endif; ?>
</div>

<div class="table-responsive">
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Pelanggan</th>
                <th>Alamat</th>
                <th>Nomor Telepon</th>
                <?php if ($level_user == 'petugas'): ?>
                    <th>Aksi</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            while ($row = mysqli_fetch_assoc($result)):
                // Jangan tampilkan Pelanggan Umum di daftar
                if ($row['PelangganID'] != 1):
            ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td><?= $row['NamaPelanggan']; ?></td>
                        <td><?= $row['Alamat']; ?></td>
                        <td><?= $row['NomorTelepon']; ?></td>
                        <?php if ($level_user == 'petugas'): ?>
                            <td>
                                <a href="edit_pelanggan.php?id=<?= $row['PelangganID']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                <a href="../proses/proses_hapus_pelanggan.php?id=<?= $row['PelangganID']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus pelanggan ini?');">Hapus</a>
                            </td>
                        <?php endif; ?>
                    </tr>
            <?php
                endif;
            endwhile;
            ?>
        </tbody>
    </table>
</div>

<?php include '../templates/footer.php'; ?>