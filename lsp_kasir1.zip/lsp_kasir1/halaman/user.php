<?php
include '../fungsi/autentikasi.php';
cekLogin();
if ($_SESSION['Level'] != 'administrator') {
    header('Location: dashboard.php');
    exit;
}
include '../config/koneksi.php';

// Ambil data user dari database
$query = "SELECT UserID, Username, Level FROM user";
$result = mysqli_query($koneksi, $query);

include '../templates/header.php';

// Menampilkan pesan sukses atau error jika ada
if (isset($_GET['pesan']) && $_GET['pesan'] == 'sukses') {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">Data user berhasil disimpan!
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
}
if (isset($_GET['pesan']) && $_GET['pesan'] == 'edit_sukses') {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">Data user berhasil diperbarui!
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
}
if (isset($_GET['pesan']) && $_GET['pesan'] == 'hapus_sukses') {
    echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">Data user berhasil dihapus!
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
}
?>

<h2>Manajemen User</h2>
<div class="row mb-3">
    <div class="col">
        <a href="dashboard.php" class="btn btn-secondary">Kembali</a>
    </div>
    <div class="col text-end">
        <a href="tambah_user.php" class="btn btn-primary">Tambah User</a>
    </div>
</div>

<div class="table-responsive">
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>No</th>
                <th>Username</th>
                <th>Level</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            while ($row = mysqli_fetch_assoc($result)):
            ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $row['Username']; ?></td>
                    <td><?= $row['Level']; ?></td>
                    <td>
                        <a href="edit_user.php?id=<?= $row['UserID']; ?>" class="btn btn-warning btn-sm">Edit</a>
                        <a href="../proses/proses_hapus_user.php?id=<?= $row['UserID']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus user ini?');">Hapus</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include '../templates/footer.php'; ?>